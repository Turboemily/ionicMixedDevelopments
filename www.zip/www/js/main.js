/**
 * Created by mac on 16/8/22.
 */
/**
 * Created by liuyujing on 16/8/23.
 */
var app = angular.module("turboemily",['ionic','turbo.controllers','turbo.routes','services','DataServices'])
// app.config(['$ionicConfigProvider',function ($ionicConfigProvider) {
//   $ionicConfigProvider.tabs.position('bottom');
// }]);
.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }
    if(window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  })
})
