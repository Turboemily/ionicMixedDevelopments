/**
 * Created by mac on 16/8/22.
 */
angular.module('turbo.controllers',[])

  // .controller("indexController",function ($scope,$ionicSlideBoxDelegate) {
  //   $scope.myActiveSlide = 1;
  //   $scope.update = function() {
  //     $ionicSlideBoxDelegate.update();
  //   }
  //
  //    // $scope.Categories = Data.getCategories();
  //
  // })
  //精选
  .controller("wellChosenController",function ($scope,Data) {

    $scope.shop = Data.getshop();

  })

  //首页
  .controller("centerController",function ($scope,Data) {
    $scope.Categories = Data.getCategories();
    $scope.shop = Data.getshop();

  })


  .controller("centerDetailsController",function ($scope,Data) {


  })

  //附近
  .controller("nearbyController",function ($scope,HTTPService,Data) {
    // $scope.Categories = Data.getCategories();
    $scope.input={'search':''};

    // $scope.myFunc = function () {
    //  $scope.h = HTTPService.getData1($scope.input.search);
    // }

    $scope.myFunc = function () {
      $scope.h = Data.SearchInfo($scope.input.search);
    }
    $scope.getSearch = Data.getSearchInfo();
    window.console.log($scope.getSearch);



  })
  //附近细节
  .controller("nearbyDetailsController",function ($scope,$stateParams,Data) {

    $scope.cookDetail = Data.getnearbyDetailCookForId($stateParams.cooksID);
  })
