/**
 * Created by mac on 16/8/24.
 */
angular.module('services', [])
.factory('HTTPService',function ($http, $q) {
  return{
    getData:function (url) {
        //加载异步请求
        var defferred = $q.defer();

        $http({
          method: 'GET',
          url: url,
          headers:{
            apikey:"ced205e0cde5295f3f582074bac9776b"
          }
        }).success(function (data, code) {
          if (parseInt(code) == 200)
            defferred.resolve(data);
          window.console.log(data);
        });

        return defferred.promise;
    },
  //   getDataDetail:function () {
  //     //加载异步请求
  //     var defferred = $q.defer();
  //
  //     $http({
  //       method: 'GET',
  //       url: "http://apis.baidu.com/baidunuomi/openapi/dealdetail?deal_id=2327781",
  //       headers:{
  //         apikey:"ced205e0cde5295f3f582074bac9776b"
  //       }
  //     }).success(function (data, code) {
  //       if (parseInt(code) == 200)
  //         defferred.resolve(data);
  //       window.console.log(data);
  //     });
  //
  //     return defferred.promise;
  //   },
  //   getDataShopInfo:function () {
  //     //加载异步请求
  //     var defferred = $q.defer();
  //
  //     $http({
  //       method: 'GET',
  //       url: "http://apis.baidu.com/baidunuomi/openapi/shopinfo?shop_id=1745896",
  //       headers:{
  //         apikey:"ced205e0cde5295f3f582074bac9776b"
  //       }
  //     }).success(function (data, code) {
  //       if (parseInt(code) == 200)
  //         defferred.resolve(data);
  //       window.console.log(data);
  //     });
  //
  //     return defferred.promise;
  //   },
  //   getDataCategories:function () {
  //     //加载异步请求
  //     var defferred = $q.defer();
  //
  //     $http({
  //       method: 'GET',
  //       url: "http://apis.baidu.com/baidunuomi/openapi/categories",
  //       headers:{
  //         apikey:"ced205e0cde5295f3f582074bac9776b"
  //       }
  //     }).success(function (data, code) {
  //       if (parseInt(code) == 200)
  //         defferred.resolve(data);
  //       window.console.log(data);
  //     });
  //
  //     return defferred.promise;
  //   }


    //在nearby的输入框中输入信息  获取到搜索的信息
    getData1: function (keyword) {
    //加载异步请求
    var defferred = $q.defer();

    $http({
      method: 'POST',
      url: 'http://apis.baidu.com/baidunuomi/openapi/searchdeals?city_id=100010000',
      headers:{
        apikey:"ced205e0cde5295f3f582074bac9776b"
      },
      // *********这边和上次获取天气预报的时候有区别  不知道什么原因
      params:{keyword:keyword}
    }).success(function (data, code) {
      if (parseInt(code) == 200)
        defferred.resolve(data);
      // window.console.log(data);
      // window.console.log(keyword);
    });

    return defferred.promise;
  }
  }
});
