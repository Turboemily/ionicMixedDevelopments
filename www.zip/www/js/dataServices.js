angular.module("DataServices",[])
.factory("Data",function (HTTPService) {
  var urlArray = ["http://apis.baidu.com/baidunuomi/openapi/cities",
  "http://apis.baidu.com/baidunuomi/openapi/dealdetail?deal_id=2327781",
  "http://apis.baidu.com/baidunuomi/openapi/shopinfo?shop_id=1745896",
  "http://apis.baidu.com/baidunuomi/openapi/categories",
  "http://apis.baidu.com/baidunuomi/openapi/dealshops?city_id=100010000&deal_id=1228062",
    "http://apis.baidu.com/baidunuomi/openapi/districts?city_id=100010000",
    "http://apis.baidu.com/baidunuomi/openapi/dealdetail",
  "http://apis.baidu.com/baidunuomi/openapi/searchshops?city_id=600010000&keyword=俏江南"];


  //categories的cook
  var cook1 = {
    cat_id: 0,
    cat_name: "",
    subcategories:[]
  };
  //shopinfo的cook
  var cook2={};

  //存储cook1对象
  var cookList1 = [];
  var promise1=HTTPService.getData(urlArray[3]);

  var promise2=HTTPService.getData(urlArray[2]);

  var promise7 = HTTPService.getData(urlArray[7]);

  //执行搜索框的操作  确保执行完成
  var promise3;
  function SearchInfo(keyword) {
    promise3 = HTTPService.getData1(keyword);
  }

  SearchInfo("肯德基");

  var cook3 = {image:'',title:'',description:''};
  var cook3List = [];

  promise1.then(function (data) {
    if(data['msg'] == "success"){
      for(var i = 0 ;i<7;i++){
        cook1=data['categories'][i];
        cookList1.push(cook1);
        // window.console.log(cook1.subcategories.length);
      }
    }
  })


  promise2.then(function (data) {
    if(data['msg'] == "success"){
        cook2['shop_name'] = data.shop.shop_name;
        cook2['address'] = data.shop.address;
        cook2['shop_url'] = data.shop.shop_url;
        cook2['open_time'] = data.shop.open_time;
        cook2['phone'] = data.shop.phone;
        cook2['featured_menus'] = data.shop.featured_menus;
        cook2['featured_service'] = data.shop.featured_service;
        cook2['introduction'] = data.shop.introduction;
        cook2['average_price'] = data.shop.average_price;
      // window.console.log(cook2);
    }

    promise3.then(function (data) {
      if(data['msg'] == 'success'){
        for(var i=0;i<data['data']['deals'].length;i++){
          cook3 = data['data']['deals'][i];
          cook3List.push(cook3);
          window.console.log('111111');
        }
      }
    })
  })

  var cooksub={subcat_id:0,subcat_name:""};
  var cooksublist;


  return{
    getCategories:function () {
      return cookList1;
    },
    getshop:function () {
      return cook2;
    },
    getnearbyDetailCookForId:function (cooksID) {
      for(var i=0;i<cookList1.length;i++){
        if(cookList1[i].cat_id === parseInt(cooksID)){
          // return cookList1[i].subcategories;
          cooksublist=[];
          for(var j=0;j<cookList1[i].subcategories.length;j++){
            cooksub=cookList1[i].subcategories[j];
            cooksublist.push(cooksub);
            return cooksublist;
            // window.console.log(cookList1[i]);
          }
         // window.console.log(cookList1[i]);
        }
      }
      return null;
    },
    SearchInfo:function (keyword) {
      promise3 = HTTPService.getData1(keyword);
    },
    getSearchInfo:function () {
      return cook3List;
    }
  }
})

//
//
// city_id
//   :
//   600350000
// city_name
//   :
//   "余杭市"
// city_pinyin
//   :
//   "yuhang"
// map_id
//   :
//   "2706"
// short_name
//   :
//   "余杭"
// short_pinyin
//   :
//   "yuhang"
